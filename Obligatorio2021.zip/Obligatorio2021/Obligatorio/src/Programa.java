import CSVReader.CSVReader;
import Clases.CastMember;
import Clases.Movie;
import Clases.MovieCastMember;
import TADs.ArbolB.ABB;
import TADs.LinkedList.Lista;
import TADs.LinkedList.ListaEnlazada;
import TADs.MyHash.MyHashImpl;

import java.io.File;
import java.util.Iterator;
import java.util.Scanner;

public class Programa {
    static ListaEnlazada title_principals_list = new ListaEnlazada<MovieCastMember>();
    static MyHashImpl movie_hash = new MyHashImpl(86000);
    static MyHashImpl cast_member_hash = new MyHashImpl(315000);


    public static void main(String[] args) {
        ABB castMemberABB=new ABB();
        Lista listaMovie=new ListaEnlazada();
        Lista listaDirectores=new ListaEnlazada();
        int[] actorAnio=new int[120];
        int[] actrizAnio=new int[120];
        ListaEnlazada LL = new ListaEnlazada();

        Scanner input = new Scanner(System.in);
        int numero_opcion;
        do {
            System.out.println(
                    "Seleccione la opción que desee:\n" +
                            "Programación 2\n" +
                            "1. Carga de datos\n" +
                            "2. Ejecutar consultas\n" +
                            "3. Salir");

            numero_opcion = input.nextInt();
            switch(numero_opcion) {
                case 1:
                    long tiempo_inicio = System.nanoTime();

                    String[] paths = {
                        "C:\\Users\\Usuario\\OneDrive\\Desktop\\Obligatorio Programacion\\IMDb names.csv",
                        "C:\\Users\\Usuario\\OneDrive\\Desktop\\Obligatorio Programacion\\IMDb movies.csv",
                        "C:\\Users\\Usuario\\OneDrive\\Desktop\\Obligatorio Programacion\\IMDb title_principals.csv",
                        //"C:\\Users\\Usuario\\OneDrive\\Desktop\\Obligatorio Programacion\\IMDb ratings.csv"
                    };

                    for (int i = 0; i < paths.length; i++) {
                        CSVReader reader = new CSVReader(new File(paths[i]));
                        Iterator<String[]> readerIterator = reader.iterator();

                        boolean header = true;

                        while (readerIterator.hasNext()) {
                            String[] row = readerIterator.next();

                            if(header){
                                header = false;
                            } else {
                                if (i == 0) {
                                    CastMember newCastMember = new CastMember();
                                    newCastMember.loadCsvRow(row);

                                    cast_member_hash.put(Integer.parseInt(row[0].substring(2)), newCastMember);
                                } else if (i == 1) {
                                    Movie newMovie = new Movie();
                                    newMovie.loadCsvRow(row);

                                    movie_hash.put(Integer.parseInt(row[0].substring(2)), newMovie);
                                } else if (i == 2) {
                                    MovieCastMember newMovieCastMember = new MovieCastMember();
                                    newMovieCastMember.loadCsvRow(row);

                                    title_principals_list.add(newMovieCastMember);
                                } /*else if (i == 3) {
                                    CastMember newCastMember = new CastMember();
                                    newCastMember.loadCsvRow(row);

                                    cast_member_hash.put(Integer.parseInt(row[0].substring(2)), newCastMember);
                                }*/
                            }
                        }
                    }

                    long executionTime =  (System.nanoTime() - tiempo_inicio) / 1000000;
                    System.out.println("Carga de datos exitosa, tiempo de ejecución de la carga: " + executionTime);

                    break;

                case 2:
//                    System.out.println(((CastMember) cast_member_hash.get(input.nextInt())).getName());
                    subMenu();
                    break;

                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcion no valida");
            }
           
        }while(numero_opcion!=3);
    }

    private static void subMenu() {
        int numero_opcion2;
        Scanner input = new Scanner(System.in);
        do {
            System.out.println(
                    "1. Indicar el Top 5 de actores/actrices que más apariciones han tenido a\n" +
                            "lo largo de los años.\n" +
                            "2. Indicar el Top 5 de las causas de muerte más frecuentes en directores\n" +
                            "y productores nacidos en Italia, Estados Unidos, Francia y UK.\n" +
                            "3. Mostrar de las 14 películas con más weightedAverage, el promedio de\n" +
                            "altura de sus actores/actrices si su valor es distinto de nulo.\n" +
                            "4. Indicar el año más habitual en el que nacen los actores y las actrices.\n" +
                            "5. Indicar el Top 10 de géneros de películas más populares, en las\n" +
                            "cuales al menos un actor/actriz tiene 2 o más hijos.\n" +
                            "6. Salir.");

            numero_opcion2 = input.nextInt();
            switch (numero_opcion2) {
                case 1:
                    top5_Apariciones();
                    break;
                case 2:
                    top5_Muertes();
                    break;
                case 3:
                    Weighted_y_Altura();
                    break;
                case 4:
                    Anio_nacimiento_habitual();
                    break;
                case 5:
                    top10_generos_y_2hijos();
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcion no valida");
            }

        } while (numero_opcion2 != 6);
    }

    private static void top5_Apariciones() {
        long tiempo_inicio = System.nanoTime();

//        MovieCastMember[] top5 = new MovieCastMember[5];
//        MyHashImpl actor0 = new MyHashImpl(5);

//        for (Object movieCastMemberObj : title_principals_list) {
//            MovieCastMember movieCastMember = (MovieCastMember) movieCastMemberObj;
//
//            if (movieCastMember.getImdbNameId)
//        }

        //Map which stores number and it's occurrence count
        MyHashImpl<Integer, Integer> countMap = new MyHashImpl(title_principals_list.size());

        //Variable which stores maximum frequency of any number
        int maxFreq = 0;

        //Traverse an array
        for(int i = 0; i < title_principals_list.size(); i++) {
            int actorId = ((MovieCastMember) title_principals_list.get(i).getValue()).getImdbNameId();

            //Get the occurrence of current element and add 1
            int freq = (int) countMap.getOrDefault(actorId, 0) + 1;

            //put the elem and its freq in a map
            countMap.put(((MovieCastMember) title_principals_list.get(i).getValue()).getImdbNameId(), freq);

            //keep track of maximum occurrence
            maxFreq = Math.max(maxFreq, freq);
        }

        System.out.println("test 1.1");

        //Declare a bucket, which store multiple values
        ListaEnlazada[] bucket = new ListaEnlazada[maxFreq + 1];

        ListaEnlazada keys = countMap.keySet();

        for(int i = 0; i < keys.size(); i++) {
            int n = (int) keys.get(i).getValue();

            int freq = countMap.get(n);

            if (bucket[freq] == null)
                bucket[freq] = new ListaEnlazada();

            bucket[freq].add(n);
        }

        int[] resultArr = new int[5];
        int count = 0;

        // Pick top k elements
        for(int i = bucket.length - 1; i >= 0; i--) {
            if (bucket[i] != null){
                for (int j = 0; j < bucket[i].size(); j++) {
                    resultArr[count++] = (int) bucket[i].get(j).getValue();

                    if (count == 5) {
                        System.out.println(resultArr);
                        break;
                    }
                }
            }
        }

        System.out.println(resultArr);

        long ejecucion = (System.nanoTime() - tiempo_inicio)/1000000;
        System.out.println("Tiempo de ejecución de la consulta: "+ ejecucion);
    }
    private static void top5_Muertes() {
        long tiempo_inicio = System.nanoTime();

        long ejecucion = (System.nanoTime() - tiempo_inicio)/1000000;
        System.out.println("Tiempo de ejecución de la consulta: "+ ejecucion);
    }
    private static void Weighted_y_Altura() {
        long tiempo_inicio = System.nanoTime();

        long ejecucion = (System.nanoTime() - tiempo_inicio)/1000000;
        System.out.println("Tiempo de ejecución de la consulta: "+ ejecucion);
    }
    private static void Anio_nacimiento_habitual() {
        long tiempo_inicio = System.nanoTime();

        long ejecucion = (System.nanoTime() - tiempo_inicio)/1000000;
        System.out.println("Tiempo de ejecución de la consulta: "+ ejecucion);
    }
    private static void top10_generos_y_2hijos() {
        long tiempo_inicio = System.nanoTime();

        long ejecucion = (System.nanoTime() - tiempo_inicio)/1000000;
        System.out.println("Tiempo de ejecución de la consulta: "+ ejecucion);
    }
}