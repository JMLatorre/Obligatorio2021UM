package TADs.MyHash;

public class Node<K extends Comparable<K>, V> {

    private K key;
    private V value;
    private Node collision = null;

    public Node(K key, V value) {
        this.key = key;
        this.value = value;
    }

    public K getKey() {
        return this.key;
    }

    public V getValue(K key) {
        if (this.key == key) {
            return this.value;
        } else {
            if (this.collision != null) {
                return (V) this.collision.getValue(key);
            }

            return null;
        }
    }

    public Node getCollision() {
        return this.collision;
    }

    public void setValue(K key, V value) {
        if (this.key == key) {
            this.value = value;
        } else {
            if (this.collision == null) {
                this.collision = new Node(key, value);
            } else {
                this.collision.setValue(key, value);
            }
        }
    }
}
