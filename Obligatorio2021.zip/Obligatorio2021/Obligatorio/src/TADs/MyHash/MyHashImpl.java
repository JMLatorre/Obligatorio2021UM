package TADs.MyHash;

import TADs.LinkedList.ListaEnlazada;

public class MyHashImpl<K extends Comparable<K>, V> implements Myhash<K, V> {
    private Node[] array;

    public MyHashImpl(int size) {
        array = new Node[size];
    }

    private int getHashIndex(K key) {
        return Integer.parseInt(key.toString()) % array.length;
    }

    @Override
    public void put(K key, V value) {
        if (array[getHashIndex(key)] == null) {
            array[getHashIndex(key)] = new Node(key, value);
        } else {
            array[getHashIndex(key)].setValue(key, value);
        }
    }

    @Override
    public V get(K key) {
        Node node = array[getHashIndex(key)];

        if (node != null) {
            return (V) node.getValue(key);
        }

        return null;
    }

    public Object getOrDefault(K key, Object defaultValue) {
        V value = get(key);

        if (value != null) {
            return value;
        }

        return defaultValue;
    }

    public ListaEnlazada keySet() {
        ListaEnlazada keys = new ListaEnlazada<Integer>();

        for (Node iteratedElm : array) {
            Node elm = iteratedElm;
            boolean hasCollision = true;

            while (hasCollision) {
                if (elm == null) {
                    break;
                }

                keys.add(elm.getKey());

                Node collision = elm.getCollision();

                hasCollision = collision != null;

                if (hasCollision) {
                    System.out.println(elm.getKey() + " Value: " + elm.getValue(elm.getKey()) + " Has collision!");
                    elm = collision;
                } else {
                    break;
                }
            }
        }

        System.out.println("Number of keys: " + keys.size());

        return keys;
    }

    public static void main(String[] args) {
        MyHashImpl x = new MyHashImpl(10);

        for (int i = 0; i < 100; i++) {
            x.put(i, "Valor de key: " + i);
        }

        for (int i = 0; i < 100; i++) {
            System.out.println(x.get(i));
        }
    }
}
