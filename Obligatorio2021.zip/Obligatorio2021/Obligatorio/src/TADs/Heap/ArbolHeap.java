package TADs.Heap;

import TADs.ArbolB.Node;

public class ArbolHeap<K extends Comparable<K>, V> {

    private Node raiz;

    private Node insertAux(Node raiz, K newkey, V value) {
        if(raiz==null)
        {
            raiz=new Node(newkey, value);

        }
        else{
            if(raiz.getKey().compareTo(newkey) < 0)
            {
                raiz.setLeftChild(insertAux(raiz.getLeftChild(), newkey, value));
            }
            else{
                raiz.setRightChild(insertAux(raiz.getRightChild(), newkey, value));
            }
        }
        return raiz;
    }

    public void insert(K key, V value) {
        raiz = insertAux( raiz, key, value);
    }

    public Node borrarMayor(Node raiz)
    {
        if(raiz.getRightChild() != null)
        {
            return borrarMayor(raiz.getRightChild());

        }
        else{
            Node aux = raiz;
            raiz.setRightChild(raiz.getLeftChild());
            return aux;
        }
    }
}
