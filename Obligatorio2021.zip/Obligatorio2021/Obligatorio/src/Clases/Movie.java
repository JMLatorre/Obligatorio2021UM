package Clases;

public class Movie {
    private String imdbTitleid;
    private String title;
    private String originalTitle;
    private int year;
    private String datePublished;
    private /*List<String>*/ String genre;
    private int duration;
    private /*List<String>*/ String country;
    private String language;
    private /*List<String>*/ String director;
    private /*List<String>*/ String writer;
    private String productionCompany;
    private /*List<String>*/ String actors;
    private String description;
    private float avgVote;
    private int votes;
    private String budget;
    private String usaGrossIncome;
    private String worldwideGrossIncome;
    private float metaScore;
    private float reviewsFromUsers;
    private float reviewsFromCritics;

    //Despues analizar
    //private Lista<MovieCastMember> listaMovieCastMember;
    private MovieRating rating;

    public Movie(){

    }

    public Movie(String imdbTitleid, String title, String originalTitle, int year, String datePublished, /*List<String>*/ String genre, int duration, /*List<String>*/ String country, String language, /*List<String>*/ String director, /*List<String>*/ String writer, String productionCompany, /*List<String>*/ String actors, String description, float avgVote, int votes, String budget, String usaGrossIncome, String worldwideGrossIncome, float metaScore, float reviewsFromUsers,
                 float reviewsFromCritics, MovieRating rating) {


        this.imdbTitleid = imdbTitleid;
        this.title = title;
        this.originalTitle = originalTitle;
        this.year = year;
        this.datePublished = datePublished;
        this.genre = genre;
        this.duration = duration;
        this.country = country;
        this.language = language;
        this.director = director;
        this.writer = writer;
        this.productionCompany = productionCompany;
        this.actors = actors;
        this.description = description;
        this.avgVote = avgVote;
        this.votes = votes;
        this.budget = budget;
        this.usaGrossIncome = usaGrossIncome;
        this.worldwideGrossIncome = worldwideGrossIncome;
        this.metaScore = metaScore;
        this.reviewsFromUsers = reviewsFromUsers;
        this.reviewsFromCritics = reviewsFromCritics;

        this.rating = rating;

    }

    public String getImdbTitleid() {
        return imdbTitleid;
    }

    public void setImdbTitleid(String imdbTitleid) {
        this.imdbTitleid = imdbTitleid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOriginalTitle() {
        return originalTitle;
    }

    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDatePublished() {
        return datePublished;
    }

    public void setDatePublished(String datePublished) {
        this.datePublished = datePublished;
    }

    public /*List<String>*/ String getGenre() {
        return genre;
    }

    public void setGenre(/*List<String>*/ String genre) {
        this.genre = genre;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public /*List<String>*/ String getCountry() {
        return country;
    }

    public void setCountry(/*List<String>*/ String country) {
        this.country = country;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public /*List<String>*/ String getDirector() {
        return director;
    }

    public void setDirector(/*List<String>*/ String director) {
        this.director = director;
    }

    public /*List<String>*/ String getWriter() {
        return writer;
    }

    public void setWriter(/*List<String>*/ String writer) {
        this.writer = writer;
    }

    public String getProductionCompany() {
        return productionCompany;
    }

    public void setProductionCompany(String productionCompany) {
        this.productionCompany = productionCompany;
    }

    public /*List<String>*/ String getActors() {
        return actors;
    }

    public void setActors(/*List<String>*/ String actors) {
        this.actors = actors;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getAvgVote() {
        return avgVote;
    }

    public void setAvgVote(float avgVote) {
        this.avgVote = avgVote;
    }

    public int getVotes() {
        return votes;
    }

    public void setVotes(int votes) {
        this.votes = votes;
    }

    public String getBudget() {
        return budget;
    }

    public void setBudget(String budget) {
        this.budget = budget;
    }

    public String getUsaGrossIncome() {
        return usaGrossIncome;
    }

    public void setUsaGrossIncome(String usaGrossIncome) {
        this.usaGrossIncome = usaGrossIncome;
    }

    public String getWorldwideGrossIncome() {
        return worldwideGrossIncome;
    }

    public void setWorldwideGrossIncome(String worldwideGrossIncome) {
        this.worldwideGrossIncome = worldwideGrossIncome;
    }

    public float getMetaScore() {
        return metaScore;
    }

    public void setMetaScore(float metaScore) {
        this.metaScore = metaScore;
    }

    public float getReviewsFromUsers() {
        return reviewsFromUsers;
    }

    public void setReviewsFromUsers(float reviewsFromUsers) {
        this.reviewsFromUsers = reviewsFromUsers;
    }

    public float getReviewsFromCritics() {
        return reviewsFromCritics;
    }

    public void setReviewsFromCritics(float reviewsFromCritics) {
        this.reviewsFromCritics = reviewsFromCritics;
    }

    public void loadCsvRow(String[] row) {

        imdbTitleid = row[0];
        imdbTitleid = row[1];
        title = row[2];
        originalTitle = row[3];
        year = year;
        datePublished = row[4];
        genre = row[5];
        duration = Integer.parseInt(row[6]);
        country = row[7];
        language = row[8];
        director = row[9];
        writer = row[10];
        productionCompany = row[11];
        actors = row[12];
        description = row[13];
        avgVote = Float.parseFloat(row[14]);
        votes = Integer.parseInt(row[15]);
        budget = row[16];
        usaGrossIncome = row[17];
        worldwideGrossIncome = row[18];

        if (row[19] == "") {
            metaScore = 0;
        } else {
            metaScore = Float.parseFloat(row[19]);
        }

        if (row[20] == "") {
            reviewsFromUsers = 0;
        } else {
            reviewsFromUsers = Float.parseFloat(row[20]);
        }

        if (row[21].trim() == "") {
            reviewsFromCritics = 0;
        } else {
            reviewsFromCritics = Float.parseFloat(row[21]);
        }

        rating = /*row[22]*/ null;
    }
}
