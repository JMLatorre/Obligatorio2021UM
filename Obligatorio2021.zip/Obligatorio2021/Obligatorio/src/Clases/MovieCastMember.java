package Clases;

public class MovieCastMember {
    private int ordering;
    private String category;
    private String job;
    private /*List<String>*/ String characters;
    private CastMember castMember;
    private int imdbTitleid;
    private int imdbNameId;

    public MovieCastMember(){

    }

    public MovieCastMember(int ordering, String category, String job, /*List<String>*/ String characters,CastMember castMember) {
        this.ordering = ordering;
        this.category = category;
        this.job = job;
        this.characters = characters;
    }

    public CastMember getCastMember() {
        return castMember;
    }

    public void setCastMember(CastMember castMember) {
        this.castMember = castMember;
    }

    public int getOrdering() {
        return ordering;
    }

    public void setOrdering(int ordering) {
        this.ordering = ordering;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public /*List<String>*/ String getCharacters() {
        return characters;
    }

    public void setCharacters(/*List<String>*/ String characters) {
        this.characters = characters;
    }

    public int getImdbTitleid() {
        return imdbTitleid;
    }

    public void setImdbTitleid(int imdbTitleid) {
        this.imdbTitleid = imdbTitleid;
    }

    public int getImdbNameId() {
        return imdbNameId;
    }

    public void setImdbNameId(int imdbNameId) {
        this.imdbNameId = imdbNameId;
    }

    public void loadCsvRow(String[] row){

        imdbTitleid = Integer.parseInt(row[0].substring(2));
        ordering = Integer.parseInt(row[1]);
        imdbNameId = Integer.parseInt(row[2].substring(2));
        category = row[3];
        job = row[4];
        characters = row[5];

    }
}
