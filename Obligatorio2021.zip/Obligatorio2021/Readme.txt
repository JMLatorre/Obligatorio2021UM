Obligatorio 2020 - Juan Martin Coronel y Juan Manuel Latorre

A continuación haremos un breve comentario de qué TADs elegimos, por qué los elegimos y de qué problemas enfrentamos durante la implementación.

TADs:
  - CastMember (Closed hash): Queríamos tener la posibilidad de poder acceder la entidad basado en la ID del actor.
  - Movies (Closed hash): Queríamos tener la posibilidad de poder acceder la entidad basado en la ID del actor.
  - MovieCastMember (ListaEnlazada): Decidimos usar una lista, para poder contar las apariciones de cada actor o película. Luego, podríamos usar el ID de cada uno para consultar la entidad entera usando los Closed hashes de CastMember y Movies.

Problemas:
  - Encontramos inconvenientes durante la implementación de MyHashImpl.keySet(), lo cual necesitábamos para poder hacer la primer consulta.
  - Creemos que la implementación de MyHashImpl se rompió en algún momento mientras creamos ListaEnlazada
  - Más allá de la extensión del plazo que nos han dado, la cual agradecemos mucho, dada una mala administración del tiempo no pudimos llegar a la entrega en las condiciones que nos hubieran gustado.