package TADs.Queue;

public class EmptyQueueException extends Exception {
}
