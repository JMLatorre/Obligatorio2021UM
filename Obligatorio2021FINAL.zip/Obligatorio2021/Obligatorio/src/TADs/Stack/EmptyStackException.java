package TADs.Stack;

public class EmptyStackException extends Exception{
}
